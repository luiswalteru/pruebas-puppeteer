/**
 * Obtiene los períodos únicos de todos los cursos
 * @param {Array} courses - Array de cursos con períodos
 * @returns {Array} Array de períodos únicos
 */
function getUniquePeriods(courses) {
  if (!courses?.length) return [];

  const allPeriods = courses.flatMap(
    (course) =>
      course?.periods?.map((period) => ({
        name: period.name,
        period: period.period,
        average: period.average,
      })) || []
  );

  // Eliminar duplicados basándose en el atributo "period"
  return allPeriods.filter(
    (period, index, array) =>
      index === array.findIndex((p) => p.period === period.period)
  );
}

/**
 * Genera el encabezado de la tabla
 * @param {Array} periods - Array de períodos
 * @param {boolean} showAveragesBySubject - Si mostrar columna de promedio
 * @returns {string} HTML del encabezado
 */
function generateTableHeader(periods, showAveragesBySubject) {
  const periodHeaders = (periods || [])
    .map((period) => `<th>${period.name}</th>`)
    .join("");

  const averageHeader = showAveragesBySubject ? `<th>Promedio</th>` : "";

  return `
    <thead>
      <tr>
        <th>Materia</th>
        ${periodHeaders}
        ${averageHeader}
      </tr>
    </thead>`;
}

/**
 * Genera una fila de materia con sus calificaciones
 * @param {Object} course - Objeto del curso
 * @param {Array} periods - Array de períodos
 * @param {boolean} showAveragesBySubject - Si mostrar promedio de la materia
 * @returns {string} HTML de la fila del curso
 */
function generateCourseRow(
  course,
  periods,
  showAveragesBySubject,
  showCategoryEvaluation
) {
  const periodCells = (periods || [])
    .map((period) => {
      const courseGrade =
        course.periods?.find((p) => p.period === period.period)?.average || "";
      return `<td class="subject-period-cell">${courseGrade}</td>`;
    })
    .join("");

  const averageCell = showAveragesBySubject
    ? `<td class="grade-cell">${course.average?.average || ""}</td>`
    : "";

  // Fila principal del curso
  let mainRow = `
    <tr class="subject-row">
      <td class="subject-name">${course.name}</td>
      ${periodCells}
      ${averageCell}
    </tr>`;

  // Generar filas adicionales para las categorías
  let categoryRows = "";

  if (course.periods && course.periods.length > 0 && showCategoryEvaluation) {
    // Recopilar todas las categorías únicas de todos los períodos
    const allCategories = new Set();

    course.periods.forEach((coursePeriod) => {
      if (coursePeriod.categories && Array.isArray(coursePeriod.categories)) {
        coursePeriod.categories.forEach((category) => {
          if (category.name) {
            allCategories.add(category.name);
          }
        });
      }
    });

    // Generar una fila por cada categoría única
    allCategories.forEach((categoryName) => {
      const categoryPeriodCells = (periods || [])
        .map((period) => {
          const coursePeriod = course.periods?.find(
            (p) => p.period === period.period
          );
          const categoryGrade =
            coursePeriod?.categories?.find((cat) => cat.name === categoryName)
              ?.average || "";
          return `<td class="subject-period-cell">${categoryGrade}</td>`;
        })
        .join("");

      const categoryAverageCell = showAveragesBySubject
        ? `<td class="grade-cell">-</td>`
        : "";

      categoryRows += `
        <tr class="subject-row category-row">
          <td class="subject-name category-name">\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0${categoryName}</td>
          ${categoryPeriodCells}
          ${categoryAverageCell}
        </tr>`;
    });
  }

  return mainRow + categoryRows;
}

/**
 * Genera el cuerpo de la tabla con todas las materias
 * @param {Array} courses - Array de cursos
 * @param {Array} periods - Array de períodos
 * @param {boolean} showAveragesBySubject - Si mostrar promedio por materia
 * @returns {string} HTML del cuerpo de la tabla
 */
function generateTableBody(
  courses,
  periods,
  showAveragesBySubject,
  showCategoryEvaluation
) {
  const courseRows = (courses || [])
    .map((course) =>
      generateCourseRow(
        course,
        periods,
        showAveragesBySubject,
        showCategoryEvaluation
      )
    )
    .join("");

  return `
    <tbody>
      ${courseRows}
    </tbody>`;
}

/**
 * Genera la sección del promedio final
 * @param {boolean} showFinalAverages - Si mostrar promedio final
 * @returns {string} HTML de la sección de promedio final
 */
function generateFinalAverageSection(student, showFinalAverages) {
  const average = student?.groupAverage?.average || "";
  return showFinalAverages
    ? '<div class="report-draft-page-table-classinfo"><div></div><div>Promedio total: ' +
        average +
        "</div></div>"
    : "";
}

/**
 * Función principal que genera el reporte estándar de calificaciones
 * @param {Object} student - Objeto del estudiante con sus cursos
 * @param {boolean} showFinalAverages - Si mostrar promedio final
 * @param {boolean} showAveragesBySubject - Si mostrar promedio por materia
 * @returns {string} HTML del reporte completo
 */
function ReplacementsStandar(
  student,
  showFinalAverages,
  showAveragesBySubject,
  showCategoryEvaluation
) {
  const periods = getUniquePeriods(student?.courses);

  const tableHeader = generateTableHeader(periods, showAveragesBySubject);
  const tableBody = generateTableBody(
    student?.courses,
    periods,
    showAveragesBySubject,
    showCategoryEvaluation
  );
  const finalAverageSection = generateFinalAverageSection(
    student,
    showFinalAverages
  );

  return `
    <div class="report-draft-page-table-wrapper">
      <table class="report-draft-page-table-main">
        ${tableHeader}
        ${tableBody}
      </table>
    </div>
    ${finalAverageSection}
  `;
}

module.exports = ReplacementsStandar;
