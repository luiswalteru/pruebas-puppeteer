const ReplacementsStandar = require("./ReplacementsStandar");
const { haveSignature } = require("./utils");

function Replacements(template, data, cssStyles, index, student) {
  // Start Document
  template = template.replace("{{STYLES}}", cssStyles);
  template = template.replace("{{REPORT_NAME}}", data.configuration.name);

  // Header
  template = template.replace(
    "{{SCHOOL_LOGO_URL}}",
    data?.school?.information_school?.school_logo
      ? data?.school?.information_school?.school_logo[0]?.url || ""
      : ""
  );
  template = template.replace(
    "{{SCHOOL_NAME}}",
    data?.school?.information_school?.school_name || ""
  );
  template = template.replace(
    "{{STUDENT_NAME}}",
    `${student?.name} ${student?.lastname}`
  );
  template = template.replace(
    "{{EDUCATION_YEAR_LEVEL}}",
    `${data?.configuration?.education_year_level || ""}`
  );
  template = template.replace(
    "{{EDUCATION_YEAR_YEAR}}",
    `${data?.configuration?.education_year_year || ""}`
  );
  template = template.replace(
    "{{DATE_PERIOD}}",
    `${data?.configuration?.report_date_period || ""}`
  );
  template = template.replace(
    "{{DATE_REPORT}}",
    `${data?.configuration?.report_date || ""}`
  );
  template = template.replace(
    "{{FONT_SIZE}}",
    `${data?.configuration?.font_size || ""}`
  );

  // Agregar clase para salto de página (excepto en la última página)
  if (index < data?.students?.length - 1) {
    template = template.replace(
      '<div class="report-draft-page report-font-size-' +
        data?.configuration?.font_size +
        '">',
      '<div class="report-draft-page report-font-size-' +
        data?.configuration?.font_size +
        ' page-break">'
    );
  }

  // Content
  template = template.replace(
    "{{CLASS_NAME}}",
    data?.configuration?.school_group?.name || ""
  );

  const showAveragesByClass = data.advanced.show_averages.find(
    (average) => average.value === "AVERAGES_BY_CLASS"
  );
  const showFinalAverages = data.advanced.show_averages.find(
    (average) => average.value === "FINAL_AVERAGES"
  );
  const showAveragesBySubject = data.advanced.show_averages.find(
    (average) => average.value === "AVERAGES_BY_SUBJECT"
  );
  const showCategoryEvaluation =
    data?.advanced?.show_category_evaluation || false;

  template = template.replace(
    "{{GROUP_AVERAGE}}",
    showAveragesByClass ? "Promedio : " + data.groupAverage.average : ""
  );

  // Content Table
  const tableStandar = ReplacementsStandar(
    student,
    showFinalAverages,
    showAveragesBySubject,
    showCategoryEvaluation
  );

  template = template.replace("{{TABLE}}", tableStandar);

  // Signatures

  const signatureLeft = data?.school?.signatures?.signature_left
    ?.signature_images
    ? `<div class="report-draft-page-signatures-left"> <img src="${data?.school?.signatures?.signature_left?.signature_images[0]?.url}" /> <div class="report-draft-page-signatures-border"></div> </div>`
    : "";
  const signatureRight = data?.school?.signatures?.signature_right
    ?.signature_images
    ? `<div class="report-draft-page-signatures-right"> <img src="${data?.school?.signatures?.signature_right?.signature_images[0]?.url}" /> <div class="report-draft-page-signatures-border"></div> </div>`
    : "";

  template = template.replace(
    "{{SIGNATURE_LEFT}}",
    haveSignature(data?.school?.signatures?.signature_left) ? signatureLeft : ""
  );

  template = template.replace(
    "{{SIGNATURE_RIGHT}}",
    haveSignature(data?.school?.signatures?.signature_right)
      ? signatureRight
      : ""
  );

  template = template.replace(
    "{{SIGNATURE_LEFT_TITLE}}",
    data?.school?.signatures?.signature_left?.title || ""
  );
  template = template.replace(
    "{{SIGNATURE_RIGHT_TITLE}}",
    data?.school?.signatures?.signature_right?.title || ""
  );
  template = template.replace(
    "{{SIGNATURE_LEFT_NAME}}",
    data?.school?.signatures?.signature_left?.name || ""
  );
  template = template.replace(
    "{{SIGNATURE_RIGHT_NAME}}",
    data?.school?.signatures?.signature_right?.name || ""
  );
  template = template.replace(
    "{{SCHOOL_ADDRESS}}",
    data?.school?.information_contact?.school_adress || ""
  );
  template = template.replace(
    "{{SCHOOL_EMAIL}}",
    data?.school?.information_contact?.school_email || ""
  );
  template = template.replace(
    "{{SCHOOL_PHONE}}",
    data?.school?.information_contact?.school_phone || ""
  );

  // Footer
  template = template.replace(
    "{{CERTIFICATIONS_IMAGES}}",
    data?.school?.certifications
      ? data?.school?.certifications
          .map((certification) => `<img src="${certification?.url}" />`)
          .join("")
      : ""
  );

  return template;
}

module.exports = Replacements;
