module.exports = {
  configuration: {
    name: "Boleta 22-09 - prueba C",
    type: "standard",
    education_year_id: "ey-es-07",
    education_year_level: "Primaria",
    education_year_year: "4.º",
    report_date_period: "2025-2026",
    report_date: "22-09-2025",
    school_group: {
      id: "35061210-30cb-11f0-8967-c5540259be55",
      name: "Clase personalización programas",
    },
    students: [
      {
        id: "782fda91-6216-11f0-b18e-33c6fcbca560",
        name: "Agustin",
        lastname: "Estudiante",
      },
      {
        id: "90c23860-3f04-11ed-827c-6107ee593ea2",
        name: "Carmen",
        lastname: "Student",
      },
      {
        id: "36724fc0-450c-11ef-9ef2-13b3f4d1b18e",
        name: "Eli",
        lastname: "Alumna",
      },
    ],
    evaluation_periods: [
      {
        id: "t01",
        name: "Trimestre 1",
      },
      {
        id: "t02",
        name: "Trimestre 2",
      },
      {
        id: "t03",
        name: "Trimestre 3",
      },
    ],
    orientation: "vertical",
    max_number_of_rows: "9",
    font_size: "14",
  },
  advanced: {
    evaluation_scale_id: "fdcfd77e-b15f-4e5c-94d1-b8d87fc4bfdc",
    show_averages: [
      {
        value: "FINAL_AVERAGES",
        label: "Promedios finales",
      },
      {
        value: "AVERAGES_BY_PERIOD",
        label: "Promedios por periodo",
      },
      {
        value: "AVERAGES_BY_SUBJECT",
        label: "Promedios por materia",
      },
      {
        value: "AVERAGES_BY_CLASS",
        label: "Promedios de la clase",
      },
    ],
    show_category_evaluation: true,
    show_materias: true,
  },
  school: {
    information_school: {
      school_name: "Colegio Nacional Alemeda",
      school_logo: [
        {
          id: "2f2358b3-674c-436f-b1e1-a50b3b911762",
          name: "logo04.png",
          url: "https://tangerine-dev1-dev-content.s3.eu-central-1.amazonaws.com/2f2358b3-674c-436f-b1e1-a50b3b911762/logo04.png",
        },
      ],
    },
    signatures: {
      signature_left: {
        title: "Director",
        name: "Thom Hansen",
        signature_images: [
          {
            id: "fceaa416-638d-4cc4-b44e-3b8bd1df7dc0",
            name: "firma001.png",
            url: "https://tangerine-dev1-dev-content.s3.eu-central-1.amazonaws.com/fceaa416-638d-4cc4-b44e-3b8bd1df7dc0/firma001.png",
          },
        ],
      },
      signature_right: {
        title: "Profesor",
        name: "Ramón Carriso",
        signature_images: [
          {
            id: "0f600d80-9c06-4d9a-b691-30c98ca3f8cf",
            name: "firma003.png",
            url: "https://tangerine-dev1-dev-content.s3.eu-central-1.amazonaws.com/0f600d80-9c06-4d9a-b691-30c98ca3f8cf/firma003.png",
          },
        ],
      },
    },
    information_contact: {
      school_adress: "Calle Alemeda Ramos 1500",
      school_phone: "000-0000-000000",
      school_email: "nacionalalameda@mail.com",
    },
    certifications: [
      {
        id: "139bc8a2-3a70-48f6-be6c-980eafe8ae9e",
        name: "mejore_anual.png",
        url: "https://tangerine-dev1-dev-content.s3.eu-central-1.amazonaws.com/139bc8a2-3a70-48f6-be6c-980eafe8ae9e/mejore_anual.png",
      },
      {
        id: "0af55455-52bc-42ff-a069-437b376652ba",
        name: "certification001.png",
        url: "https://tangerine-dev1-dev-content.s3.eu-central-1.amazonaws.com/0af55455-52bc-42ff-a069-437b376652ba/certification001.png",
      },
      {
        id: "50079601-62d9-4aec-ba6d-f33d4443853f",
        name: "certification002.png",
        url: "https://tangerine-dev1-dev-content.s3.eu-central-1.amazonaws.com/50079601-62d9-4aec-ba6d-f33d4443853f/certification002.png",
      },
      {
        id: "a28d0ede-0409-4ecf-bf60-03b8ff36d78b",
        name: "school_destacado.png",
        url: "https://tangerine-dev1-dev-content.s3.eu-central-1.amazonaws.com/a28d0ede-0409-4ecf-bf60-03b8ff36d78b/school_destacado.png",
      },
    ],
  },
  groupAverage: {
    average: "3.72",
    averageCalculated: 0.744,
  },
  students: [
    {
      id: "e195d670-ff73-11ef-867f-a910353ca6fe",
      name: "Agustín",
      lastname: "Costa",
    },
    {
      id: "e3caf860-ff93-11ef-942a-e562f12fc81f",
      name: "Agustín",
      lastname: "Costa1",
    },
    {
      id: "2a6b6d11-bbdb-11ef-bacf-9f021365df4e",
      name: "Ana Luz",
      lastname: "Alex",
      courses: [
        {
          id: "a098ccd0-e20f-11ef-b060-df97e691ed2a",
          name: "Alex Gradebook Inglés! (solo modulos)",
          periods: [
            {
              id: "4b98de44-5763-45aa-8a58-f743eb2a4035",
              average: "11",
              averageCalculated: null,
              period: "t01",
              name: "Trimestre 1",
              categories: [
                {
                  id: "326a9b72-9469-4e02-a583-a0401b66cd42",
                  name: "Alex Categoría 1",
                  average: "1",
                  averageCalculated: 0.85,
                },
                {
                  id: "6e4e295b-56bd-42c3-b453-1d4f3717a219",
                  name: "Alex Categoría 1 prueba",
                  average: "2",
                  averageCalculated: 1,
                },
              ],
            },
            {
              id: "bf82d5e0-c02a-42b2-b42e-7685686d1b01",
              average: "88",
              averageCalculated: null,
              period: "t02",
              name: "Trimestre 2",
              categories: [
                {
                  id: "326a9b72-9469-4e02-a583-a0401b66cd42",
                  name: "Alex Categoría 1",
                  average: "3",
                  averageCalculated: 0.85,
                },
                {
                  id: "6e4e295b-56bd-42c3-b453-1d4f3717a219",
                  name: "Alex Categoría 1 prueba",
                  average: "4",
                  averageCalculated: 1,
                },
              ],
            },
          ],
          average: {
            id: "ea4eef2c-4397-417b-86d4-0a2e1fa42995",
            average: "111",
            averageCalculated: null,
          },
        },
        {
          id: "a0f21060-e20f-11ef-b060-df97e691ed2a",
          name: "Matemáticas 1",
          periods: [
            {
              id: "ef68e5ce-4b6f-45c6-abe5-aa2f757c106b",
              average: "3.5",
              averageCalculated: 0.7,
              period: "t01",
              name: "Trimestre 1",
              categories: [],
            },
            {
              id: "b964acc5-7bc6-4a0d-8e56-66bc45c650a3",
              average: "99",
              averageCalculated: null,
              period: "t02",
              name: "Trimestre 2",
              categories: [],
            },
          ],
          average: {
            id: "be6e492a-0608-41f3-bad0-7490dfedf7ce",
            average: "22",
            averageCalculated: null,
          },
        },
      ],
    },
    {
      id: "e1a6c660-ff73-11ef-867f-a910353ca6fe",
      name: "Julia",
      lastname: "Ortiz",
    },
    {
      id: "e3dc0f60-ff93-11ef-942a-e562f12fc81f",
      name: "Julia1",
      lastname: "Ortiz1",
    },
    {
      id: "e1b6cbf0-ff73-11ef-867f-a910353ca6fe",
      name: "Leonardo",
      lastname: "Nuñez",
    },
    {
      id: "e3ecd840-ff93-11ef-942a-e562f12fc81f",
      name: "Leonardo1",
      lastname: "Nuñez1",
    },
    {
      id: "3bec5271-bbdb-11ef-bacf-9f021365df4e",
      name: "Lucas",
      lastname: "Alex",
      courses: [
        {
          id: "a098ccd0-e20f-11ef-b060-df97e691ed2a",
          name: "Alex Gradebook Inglés! (solo modulos)",
          periods: [
            {
              id: "2308c0f5-39e3-4c95-98b2-b650c086e17c",
              average: "4.05",
              averageCalculated: 0.81,
              period: "t01",
              name: "Trimestre 1",
              categories: [
                {
                  id: "326a9b72-9469-4e02-a583-a0401b66cd42",
                  name: "Alex Categoría 1",
                  average: "3.75",
                  averageCalculated: 0.75,
                },
                {
                  id: "6e4e295b-56bd-42c3-b453-1d4f3717a219",
                  name: "Alex Categoría 1",
                  average: "4.5",
                  averageCalculated: 0.9,
                },
              ],
            },
            {
              id: "6e43ff7e-b856-45ae-a5db-3f95f109d8b1",
              average: null,
              averageCalculated: null,
              period: "t02",
              name: "Trimestre 2",
              categories: [],
            },
          ],
          average: {
            id: "50a90b89-7de7-4195-8980-89a08c2e173d",
            average: "4.05",
            averageCalculated: 0.81,
          },
        },
        {
          id: "a0f21060-e20f-11ef-b060-df97e691ed2a",
          name: "B",
          periods: [
            {
              id: "3bf46e95-e4dd-4f36-87a4-475bddb55a52",
              average: "3.5",
              averageCalculated: 0.7,
              period: "t01",
              name: "Trimestre 1",
              categories: [],
            },
            {
              id: "04bfc00a-b768-40d0-9097-2346f1da0a59",
              average: null,
              averageCalculated: null,
              period: "t02",
              name: "Trimestre 2",
              categories: [],
            },
          ],
          average: {
            id: "f0c66e73-7151-4f10-8722-8474762762cd",
            average: null,
            averageCalculated: null,
          },
        },
      ],
      groupAverage: {
        average: "4.05",
        averageCalculated: 0.81,
      },
    },
    {
      id: "e171d3b0-ff73-11ef-867f-a910353ca6fe",
      name: "Lucia",
      lastname: "Jimenez",
    },
    {
      id: "e39e6a20-ff93-11ef-942a-e562f12fc81f",
      name: "Lucia 1",
      lastname: "Jimenez1",
    },
    {
      id: "e1e8ff80-ff73-11ef-867f-a910353ca6fe",
      name: "Luís",
      lastname: "Palacios",
    },
    {
      id: "e1849860-ff73-11ef-867f-a910353ca6fe",
      name: "Luís Antonio",
      lastname: "Rodriguez",
    },
    {
      id: "e3b79770-ff93-11ef-942a-e562f12fc81f",
      name: "Luís Antonio1",
      lastname: "Rodriguez1",
    },
    {
      id: "e4204450-ff93-11ef-942a-e562f12fc81f",
      name: "Luís1",
      lastname: "Palacios1",
    },
    {
      id: "e1c85820-ff73-11ef-867f-a910353ca6fe",
      name: "María",
      lastname: "Ledesma Ortiz",
    },
    {
      id: "e3fd04e0-ff93-11ef-942a-e562f12fc81f",
      name: "María1",
      lastname: "Ledesma Ortiz1",
    },
    {
      id: "e1d8d2e0-ff73-11ef-867f-a910353ca6fe",
      name: "Mikel",
      lastname: "Castillo",
    },
    {
      id: "e40fc990-ff93-11ef-942a-e562f12fc81f",
      name: "Mikel1",
      lastname: "Castillo1",
    },
    {
      id: "48760221-bbdb-11ef-bacf-9f021365df4e",
      name: "Rosana",
      lastname: "Alex",
      courses: [
        {
          id: "a0f21060-e20f-11ef-b060-df97e691ed2a",
          name: "B",
          periods: [
            {
              id: "c3f5a29a-55ab-45c7-8063-dceb3071ef25",
              average: null,
              averageCalculated: null,
              period: "t01",
              name: "Trimestre 1",
              categories: [],
            },
            {
              id: "16e4109d-769b-49bc-b489-8ac6eeb50d4a",
              average: null,
              averageCalculated: null,
              period: "t02",
              name: "Trimestre 2",
              categories: [],
            },
            {
              id: "484d5c1d-c3b3-474f-995b-4f185953a9af",
              average: null,
              averageCalculated: null,
              period: "t03",
              name: "Trimestre 3",
              categories: [],
            },
          ],
          average: {
            id: "21a15b91-9e3b-4b7d-b40b-39597f76cb8f",
            average: null,
            averageCalculated: null,
          },
        },
      ],
    },
    {
      id: "e3840450-ff93-11ef-942a-e562f12fc81f",
      name: "Sofía 1",
      lastname: "Ramírez1",
    },
  ],
};
